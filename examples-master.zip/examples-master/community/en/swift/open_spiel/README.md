# Welcome
This directory contains OpenSpiel Swift tutorials.

[OpenSpiel + Swift for TensorFlow](https://github.com/deepmind/open_spiel/blob/master/swift) is a collection of environments and algorithms for research in general reinforcement learning and search/planning in games.
